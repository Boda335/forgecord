module.exports = {
  async onLoad() {},
};
